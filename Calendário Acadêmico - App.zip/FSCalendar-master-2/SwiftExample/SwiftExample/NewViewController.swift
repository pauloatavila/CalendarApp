//
//  NewViewController.swift
//  SwiftExample
//
//  Created by Paulo Atavila on 24/05/16.
//  Copyright © 2016 wenchao. All rights reserved.
//

import UIKit
import CoreData

class NewViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var nomeEvento: UILabel!
    @IBOutlet weak var tipoEvento: UILabel!
    @IBOutlet weak var descEvento: UILabel!
    @IBOutlet weak var dtInicioEvento: UILabel!
    @IBOutlet weak var dtFimEvento: UILabel!
    @IBOutlet weak var anexoEvento: UILabel!
    @IBOutlet weak var tituloAnexo: UILabel!
    @IBAction func compartilhar(sender: AnyObject) { //Botão de compartilhar o evento
        let firstActivityItem = "Atenção: \(titleString)"
        let secondActivityItem = "Inicia-se em \(dtInicioEvento.text!)"
        let hashtag = "#UFT #CalendarioAcademico"
        let activityViewController: UIActivityViewController = UIActivityViewController(activityItems: [firstActivityItem, secondActivityItem, hashtag], applicationActivities: nil)
        self.presentViewController(activityViewController, animated: true, completion: nil)
        
    }

    
    var titleString: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("********* CHAMADO ***********")

        self.nomeEvento.text = self.titleString
        print("Evento -\(titleString)-")
        
        let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let context : NSManagedObjectContext = appDel.managedObjectContext
        let request = NSFetchRequest(entityName: "Eventos")
        request.returnsObjectsAsFaults = false
        print("1")
        request.predicate = NSPredicate(format: "nome = %@", titleString)
        do {
            let results = try context.executeFetchRequest(request)
            print("2")
            if results.count > 0 {
                print("3")
                for result in results {
                    print("4")
                    let calend = result.valueForKey("calendario") as! String
                    let dtIn = result.valueForKey("dataInicio") as! String
                    
                    print("O calendario é: \(calend) e a dtI \(dtIn)")
                    
                    if (calend == masterCalendario){
                        if let tipo = result.valueForKey("tipo") {
                            tipoEvento.text = tipo as? String
                        }
                        if let desc = result.valueForKey("descricao") {
                            descEvento.text = desc as? String
                        }
                        if let dtI = result.valueForKey("dataInicio") {
                            var dataArr = dtI.componentsSeparatedByString("-") //separa o array pelos "-"
                            let ano = dataArr[0]
                            var mes = dataArr[1]
                            let dia = dataArr[2]
                            if (mes == "01"){
                                mes = "Janeiro"
                            } else if (mes == "02"){
                                mes = "Feveireiro"
                            } else if (mes == "03"){
                                mes = "Março"
                            }else if (mes == "04"){
                                mes = "Abril"
                            } else if (mes == "05"){
                                mes = "Maio"
                            } else if (mes == "06"){
                                mes = "Junho"
                            } else if (mes == "07"){
                                mes = "Julho"
                            } else if (mes == "08"){
                                mes = "Agosto"
                            } else if (mes == "09"){
                                mes = "Setembro"
                            } else if (mes == "10"){
                                mes = "Outubro"
                            } else if (mes == "11"){
                                mes = "Novembro"
                            } else {
                                mes = "Dezembro"
                            }
                            dtInicioEvento.text = "\(dia) de \(mes) de \(ano)"
                        }
                        if let dtF = result.valueForKey("dataFim") {
                            let diaTodo = result.valueForKey("diaTodo") as! String
                            if (diaTodo == "true") {
                                dtFimEvento.text = "O evento ocorrerá por todo o dia"
                            } else {
                                var dataArr = dtF.componentsSeparatedByString("-") //separa o array pelos "-"
                                let ano = dataArr[0]
                                var mes = dataArr[1]
                                let dia = dataArr[2]
                                if (mes == "01"){
                                    mes = "Janeiro"
                                } else if (mes == "02"){
                                    mes = "Feveireiro"
                                } else if (mes == "03"){
                                    mes = "Março"
                                }else if (mes == "04"){
                                    mes = "Abril"
                                } else if (mes == "05"){
                                    mes = "Maio"
                                } else if (mes == "06"){
                                    mes = "Junho"
                                } else if (mes == "07"){
                                    mes = "Julho"
                                } else if (mes == "08"){
                                    mes = "Agosto"
                                } else if (mes == "09"){
                                    mes = "Setembro"
                                } else if (mes == "10"){
                                    mes = "Outubro"
                                } else if (mes == "11"){
                                    mes = "Novembro"
                                } else {
                                    mes = "Dezembro"
                                }
                                dtFimEvento.text = "\(dia) de \(mes) de \(ano)"
                            }
                        }
                        if let anex = result.valueForKey("anexo") {
                            if (anex as! String == ""){
                                tituloAnexo.text = ""
                            }
                            anexoEvento.text = anex as? String
                        }
                    }
                    
                    
                }
            }
            
            
        } catch {
            print("Error to ShowDentro")
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
