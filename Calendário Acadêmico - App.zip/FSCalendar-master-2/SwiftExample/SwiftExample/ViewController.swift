//
//  ViewController.swift
//  SwiftExample
//
//  Created by Wenchao Ding on 9/3/15.
//  Copyright (c) 2015 wenchao. All rights reserved.
//

import UIKit
import CoreData


var selectData = ""
var datesWithEvents = ["", ""]


class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate,FSCalendarDataSource, FSCalendarDelegate {

    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var calendarHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var selecione: UILabel!
    
    var objects: NSMutableArray! = NSMutableArray()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("************************************************")
        print("*****************MasterCalendar*****************")
        print(masterCalendario)
        print(masterCalendario2)
        calendar.scrollDirection = .Vertical
        calendar.appearance.caseOptions = [.HeaderUsesUpperCase,.WeekdayUsesUpperCase]
//        calendar.selectDate(calendar.dateWithYear(2015, month: 10, day: 10))
        
        
        
        //CORE DATA
        
        if(masterCalendario != masterCalendario2){
            print("SIIIIIM")
            masterCalendario2 = masterCalendario
            let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            let context : NSManagedObjectContext = appDel.managedObjectContext
                        
            // Preencher o array com as datas que possuem eventos:
            let request = NSFetchRequest(entityName: "Eventos")
            request.returnsObjectsAsFaults = false
            
            request.predicate = NSPredicate(format: "calendario = %@", masterCalendario)
            datesWithEvents.removeAll()
            print("Removeu tudo")
            
            do {
                let results = try context.executeFetchRequest(request)
                
                
                let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
                let context : NSManagedObjectContext = appDel.managedObjectContext
                let request = NSFetchRequest(entityName: "Eventos")
                request.returnsObjectsAsFaults = false
                
                request.predicate = NSPredicate(format: "calendario = %@", masterCalendario)
                do {
                    let results = try context.executeFetchRequest(request)
                    
                    if results.count > 0 {
                        for result in results {
                            if let dtI = result.valueForKey("dataInicio") {
                                datesWithEvents.append(dtI as! String)
                            }
                        }
                    }
                    
                    
                } catch {
                    print("Error to ShowFora")
                }

                
                
                
                
//                var iniicio = " "
//                var fiim = " "
//                var noome = " "
//                var anoI:Int?
//                var mesI:Int?
//                var diaI:Int?
//                
//                var dataI:String
//                var dataArrI = [" "]
//                
//                if results.count > 0 {
//                    for result in results {
//                        
//                        
//                        if let dataInicio = result.valueForKey("dataInicio") {
//                            datesWithEvents.append(dataInicio as! String)
//                            print("Vetor Add, evendo em: ")
//                            print(dataInicio)
//                            iniicio = dataInicio as! String
//                        }
//                        
//                        if let dataFim = result.valueForKey("dataFim"){
//                            fiim = dataFim as! String
//                            print("dtF: \(fiim)")
//                        }
//                        
//                        if let nomeEvent = result.valueForKey("nome"){
//                            eventsOfDates.append(nomeEvent as! String)
//                            print("Vetor Add, nome do evento: ")
//                            print(nomeEvent)
//                            noome = nomeEvent as! String
//                        }
//                        print("Eiii")
//                        
//                        if (iniicio != fiim){
//                            print("Eiii2")
//                            dataI = "\(iniicio)" // Separa a string data para ser modificada até chegar na fdata fim
//                            dataArrI = dataI.componentsSeparatedByString("-") //separa o array pelos "-"
//                            anoI = Int (dataArrI[0])
//                            mesI = Int (dataArrI[1])
//                            diaI = Int (dataArrI[2])
//                            
//                            while (iniicio != fiim){
//                                if (diaI >= 31){
//                                    if (mesI >= 12){
//                                        anoI = anoI! + 1
//                                        mesI = 1
//                                    } else {
//                                        mesI = mesI! + 1
//                                    }
//                                    diaI=0
//                                }
//                                diaI = diaI! + 1
//                                if (mesI < 10 && diaI < 10){
//                                    iniicio = "\(anoI!)-0\(mesI!)-0\(diaI!)"
//                                } else if (mesI < 10){
//                                    iniicio = "\(anoI!)-0\(mesI!)-\(diaI!)"
//                                } else if (diaI < 10){
//                                    iniicio = "\(anoI!)-\(mesI!)-0\(diaI!)"
//                                } else {
//                                    iniicio = "\(anoI!)-\(mesI!)-\(diaI!)"
//                                }
//                                print(iniicio)
//                                datesWithEvents.append(iniicio)
//                                eventsOfDates.append(noome)
//                                
//                            }
//                            
//                        }
//                        
//                    }
//                }
                
                
            } catch {
                print("Error to Show")
            }
            
            print("Número de eventos: \(datesWithEvents.count)")
        }  

    }
    

//    func minimumDateForCalendar(calendar: FSCalendar) -> NSDate {
//        return calendar.dateWithYear(2015, month: 1, day: 1)
//    }
//    
//    func maximumDateForCalendar(calendar: FSCalendar) -> NSDate {
//        return calendar.dateWithYear(2016, month: 10, day: 31)
//    }
    
    func calendar(calendar: FSCalendar, numberOfEventsForDate date: NSDate) -> Int {
        // vai preencher o calendario com os eventos daquele calendario (ex: Palmas-2016.1)
        var i=0
        for (i=0; i<datesWithEvents.count; i += 1){
            if (calendar.stringFromDate(date) == datesWithEvents[i]){
                return 1
            }
        }
        return 0

    }

    func calendarCurrentPageDidChange(calendar: FSCalendar) {
        NSLog("change page to \(calendar.stringFromDate(calendar.currentPage))")
    }
    
    func calendar(calendar: FSCalendar, didSelectDate date: NSDate) {
        NSLog("calendar did select date \(calendar.stringFromDate(date))")
        selectData = "\(calendar.stringFromDate(date))" //passa o dia selecionado caso os detalhes de um evento sejam solicitados
        let data: String = "\(calendar.stringFromDate(date))" // Prepara a string data para ser modificada para o formato dd/mm/aaaa
        var dataArr = data.componentsSeparatedByString("-") //separa o array pelos "-"
        let ano = dataArr[0]
        let mes = dataArr[1]
        let dia = dataArr[2]
        
        objects.removeAllObjects() // limpa o arry com os lixos que poderiam conter de outras buscas
        
        
        let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let context : NSManagedObjectContext = appDel.managedObjectContext
        let request = NSFetchRequest(entityName: "Eventos")
        request.returnsObjectsAsFaults = false
        request.predicate = NSPredicate(format: "dataInicio = %@", selectData)
        do {
            let results = try context.executeFetchRequest(request)
            
            if results.count > 0 {
                for result in results {
                    // Aqui estão os eventos com a data de inicio igual a data selecionada
                    let calendario = result.valueForKey("calendario")
                    if ((calendario as! String) == masterCalendario){ //Se co calendario vinculado a data for igual ao calendario que está sendo visualizado, é capturado o nome do evento para a lista
                        let nome = result.valueForKey("nome")
                        self.objects.addObject(nome!)
                    }
                    
                }
                
            }
            
            
        } catch {
            print("Error to ShowFora")
        }
        
        selecione.text = "\(objects.count) Evento(s) para \(dia)/\(mes)/\(ano)" //mostra o dia selecionado na pag do calendário
        
        self.tableView.reloadData()
    }
    
    func calendar(calendar: FSCalendar, boundingRectWillChange bounds: CGRect, animated: Bool) {
        calendarHeightConstraint.constant = bounds.height
        view.layoutIfNeeded()
    }
    
//    func calendar(calendar: FSCalendar, imageForDate date: NSDate) -> UIImage? {
//        var i=0;
//        for (i=0; i<datesWithCat.count; i = i+1){
//            if (calendar.stringFromDate(date) == datesWithCat[i]){
//                return true ? UIImage(named: "icon_event") : nil
//            }
//        }
//        return false ? UIImage(named: "icon_event") : nil
//    }
    
    
    //Table View
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.objects.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) as! TableViewCell
        cell.titleLabel.text = self.objects.objectAtIndex(indexPath.row) as? String
        return cell
    }
    
    func tableView(tableView: UITableView, didDeselectRowAtIndexPath indexPath: NSIndexPath) {
        self.performSegueWithIdentifier("details", sender: self)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "details"){
            var upcoming: NewViewController = segue.destinationViewController as! NewViewController
            let indexPath = self.tableView.indexPathForSelectedRow!
            let titleString = self.objects.objectAtIndex(indexPath.row) as? String
            
            upcoming.titleString = titleString
            self.tableView.deselectRowAtIndexPath(indexPath, animated: true)
        }
    }

    
}

