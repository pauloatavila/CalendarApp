////
////  Inicial.swift
////  SwiftExample
////
////  Created by Paulo Atavila on 02/06/16.
////  Copyright © 2016 wenchao. All rights reserved.
////
//
//import UIKit
//import CoreData
//import SystemConfiguration
//
//var masterCalendario = "Palmas-2016.1" //só vai mostrar eventos do calendário escolhido
//var masterCalendario2 = "2016.1" //só vai mostrar eventos do calendário escolhido
//var dowload = 0
//var objectsCalendarios: NSMutableArray! = NSMutableArray()
//
//
//class Inicial: UIViewController, UITableViewDataSource, UITableViewDelegate {
//    
//    @IBOutlet weak var actInd: UIActivityIndicatorView!
//    @IBOutlet weak var atualizandoC: UILabel!
//    @IBOutlet weak var tableView: UITableView!
//    
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        //Verifica conexão com a internet
//        if (Functions.isConnectedToNetwork()){
//            print("**CONECTADO**")
//            
//            if (dowload == 0){
//                dispatch_async(dispatch_get_main_queue(), {
//                    NSOperationQueue.mainQueue().addOperationWithBlock(){
//                        self.atualizandoC.text = "Verificando Atualização..."
//                        dowload = 1 //Para que o usuário só faça o dowload uma vez
//                        self.actInd.startAnimating()
//                        
//                        // JSON
//                        
//                        let url = NSURL(string: "https://sistemas.uft.edu.br/calendario/api/calendario/calendar?type=academico")!
//                        
//                        let task = NSURLSession.sharedSession().dataTaskWithURL(url) { (data, response, error) -> Void in
//                            if let urlContent = data {
//                                
//                                do{
//                                    let jsonResult = try NSJSONSerialization.JSONObjectWithData(urlContent, options: NSJSONReadingOptions.MutableContainers)
//                                    //                                 print(jsonResult)
//                                    
//                                    //                                 Encriptar o Json
//                                    let stringRepresentation = String(jsonResult["message"]!!["calendars"]!!)
//                                    let chaveHash = self.md5(string: stringRepresentation)
//                                    print("Chave Hash: \(chaveHash)")
//                                    var chaveVerifc = ""
//                                    if NSUserDefaults.standardUserDefaults().objectForKey("chaveH") != nil {
//                                        chaveVerifc = NSUserDefaults.standardUserDefaults().stringForKey("chaveH")!
//                                        //                                    print("Isso que ta demorando???")
//                                    }
//                                    //                                print("Maybe")
//                                    if ( chaveVerifc != chaveHash){
//                                        print("É diferente!!! chaveHash: \(chaveHash)    chaveVerifc: \(chaveVerifc)")
//                                        NSUserDefaults.standardUserDefaults().setObject(chaveHash, forKey: "chaveH")
//                                        // Atualiza o valor da chave
//                                        
//                                        if ((jsonResult["status"] as! String) == "OK"){ // Só executa se o Status estiver OK
//                                            
//                                            
//                                            
//                                            let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
//                                            let context : NSManagedObjectContext = appDel.managedObjectContext
//                                            
//                                            // Apagar todos os eventos armazenados
//                                            var request = NSFetchRequest(entityName: "Calendarios")
//                                            request.returnsObjectsAsFaults = false
//                                            do {
//                                                let results = try context.executeFetchRequest(request)
//                                                if results.count>0 {
//                                                    for result in results {
//                                                        if let name = result.valueForKey("lista"){
//                                                            context.deleteObject(result as! NSManagedObject)
//                                                            do { try context.save() } catch {}
//                                                        }
//                                                    }
//                                                }
//                                            } catch {
//                                                print("erro")
//                                            }
//                                            
//                                            
//                                            
//                                            
//                                            
//                                            
//                                            
//                                            
//                                            
//                                            
//                                            
//                                            
//                                            let newEvent = NSEntityDescription.insertNewObjectForEntityForName("Calendarios", inManagedObjectContext: context)
//                                            var i=0;
//                                            for (i=0; i<(jsonResult["message"]!!["calendars"]!!.count); i+=1){ //Salvar os calendários disponíveis
//                                                var texto = jsonResult["message"]!!["calendars"]!![i]["name"]!! as! String
//                                                newEvent.setValue(texto, forKey: "lista")
//                                                objectsCalendarios.addObject(texto)
//                                            }
////                                            self.tableView.reloadData()
//                                            
//                                            
//                                            // CORE DATA
//                                            
//                                            // Apagar todos os eventos armazenados
//                                            request = NSFetchRequest(entityName: "Eventos")
//                                            request.returnsObjectsAsFaults = false
//                                            do {
//                                                let results = try context.executeFetchRequest(request)
//                                                if results.count>0 {
//                                                    for result in results {
//                                                        if let name = result.valueForKey("nome"){
//                                                            context.deleteObject(result as! NSManagedObject)
//                                                            do { try context.save() } catch {}
//                                                        }
//                                                    }
//                                                }
//                                            } catch {
//                                                print("erro")
//                                            }
//                                            
//                                            var j=0
//                                            for (i=0; i<(jsonResult["message"]!!["calendars"]!!.count); i+=1){
//                                                
//                                                for (j=0; j<jsonResult["message"]!!["calendars"]!![i]["events"]!!.count; j+=1){
//                                                    
//                                                    
//                                                    
//                                                    print("Evento [\(i)][\(j)]")
//                                                    print(jsonResult["message"]!!["calendars"]!![i]["events"]!![j]["name"]!!)
//                                                    
//                                                    let dataInicio: String = "\(jsonResult["message"]!!["calendars"]!![i]["events"]!![j]["startDate"]!!)" // Prepara a string data para ser modificada sem a hora
//                                                    var dataArrI = dataInicio.componentsSeparatedByString("T") //separa o array pelo "T"
//                                                    let inicio = dataArrI[0]
//                                                    
//                                                    print(inicio)
//                                                    
//                                                    let fim:String
//                                                    
//                                                    if ((jsonResult["message"]!!["calendars"]!![i]["events"]!![j]["allDay"]!!) as! NSObject == false){
//                                                        let dataFim: String = "\(jsonResult["message"]!!["calendars"]!![i]["events"]!![j]["endDate"]!!)" // Prepara a string data para ser modificada sem a hora
//                                                        var dataArrF = dataFim.componentsSeparatedByString("T") //separa o array pelo "T"
//                                                        fim = dataArrF[0]
//                                                        
//                                                        print(fim)
//                                                        
//                                                    } else {
//                                                        fim = inicio
//                                                        print(jsonResult["message"]!!["calendars"]!![i]["events"]!![j]["allDay"]!!)
//                                                    }
//                                                    
//                                                    
//                                                    
//                                                    
//                                                    
//                                                    let newEvent = NSEntityDescription.insertNewObjectForEntityForName("Eventos", inManagedObjectContext: context)
//                                                    if ((jsonResult["message"]!!["calendars"]!![i]["events"]!![j]["attachmentUrl"]!!) as! NSObject == false){
//                                                        newEvent.setValue("", forKey: "anexo")
//                                                    } else {
//                                                        newEvent.setValue(jsonResult["message"]!!["calendars"]!![i]["events"]!![j]["attachmentUrl"]!!, forKey: "anexo")
//                                                    }
//                                                    newEvent.setValue(inicio, forKey: "dataInicio")
//                                                    
//                                                    newEvent.setValue(fim, forKey: "dataFim")
//                                                    if ((jsonResult["message"]!!["calendars"]!![i]["events"]!![j]["description"]!!) as! NSObject == false){
//                                                        newEvent.setValue(jsonResult["message"]!!["calendars"]!![i]["events"]!![j]["name"]!!, forKey: "descricao")
//                                                    } else {
//                                                        newEvent.setValue(jsonResult["message"]!!["calendars"]!![i]["events"]!![j]["description"]!!, forKey: "descricao")
//                                                    }
//                                                    if ((jsonResult["message"]!!["calendars"]!![i]["events"]!![j]["allDay"]!!) as! NSObject == false){
//                                                        newEvent.setValue("false", forKey: "diaTodo")
//                                                    } else {
//                                                        newEvent.setValue("true", forKey: "diaTodo")
//                                                    }
//                                                    newEvent.setValue(jsonResult["message"]!!["calendars"]!![i]["events"]!![j]["name"]!!, forKey: "nome")
//                                                    newEvent.setValue(jsonResult["message"]!!["calendars"]!![i]["events"]!![j]["type"]!!, forKey: "tipo")
//                                                    newEvent.setValue(jsonResult["message"]!!["calendars"]!![i]["name"], forKey: "calendario");
//                                                    
//                                                    do {
//                                                        try context.save()
//                                                        print("Salvou o Evento")
//                                                    } catch {
//                                                        print("Error to save")
//                                                    }
//                                                    
//                                                    
//                                                }
//                                            }
//                                        } else {
//                                            self.atualizandoC.text = "Connection Fail" // Se o status for KO, é informdo ao usuário que a conexão falhou
//                                        }
//                                    } else {
//                                        
//                                        
//                                        // Consultar os calendarios salvos
//                                        let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
//                                        let context: NSManagedObjectContext = appDel.managedObjectContext
//                                        let request = NSFetchRequest(entityName: "Calendarios")
//                                        request.returnsObjectsAsFaults = false
//                                        
//                                        do {
//                                            let results = try context.executeFetchRequest(request)
//                                            if results.count > 0 {
//                                                for result in results {
//                                                    objectsCalendarios.addObject(result.valueForKey("lista")!)
//                                                }
//                                            }
//                                        } catch {
//                                            print("error to show - lista")
//                                        }
//                                        self.atualizandoC.text = "Selecione um Calendário"
//                                        if (objectsCalendarios.count == 0){
//                                            self.atualizandoC.text = "Nenhum calendário disponível"
//                                        }
//                                        //                                    self.tableView.reloadData()
//                                        self.actInd.stopAnimating()
//                                    }
//                                    
//                                    
//                                } catch {
//                                    print("JSON Serealization failed")
//                                }
//                                
//                            }
//                        }
//                        
//                        task.resume()
//                    }
//                    
//                    
//                })
//                
//                
//                
//            }
//        } else {
//            print("**DESCONECTADO**")
//            
//            let refreshAlert = UIAlertController(title: "Sem conexão", message: "Seu dispositivo não possui conexão com a internet, portanto as informações podem estar desatualizadas.", preferredStyle: UIAlertControllerStyle.Alert)
//            
//            refreshAlert.addAction(UIAlertAction(title: "Ok", style: .Cancel, handler: { (action: UIAlertAction!) in
//                print("Ok selecioando")
//            }))
//            
//            presentViewController(refreshAlert, animated: true, completion: nil)
//            
//            
//        }
//        
//        // Executa sempre - motra a tabela
//        print("executa sempre")
//        
//        objectsCalendarios.removeAllObjects()
//        
//        
//        // Consultar os calendarios salvos
//        let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
//        let context: NSManagedObjectContext = appDel.managedObjectContext
//        let request = NSFetchRequest(entityName: "Calendarios")
//        request.returnsObjectsAsFaults = false
//        
//        do {
//            let results = try context.executeFetchRequest(request)
//            if results.count > 0 {
//                for result in results {
//                    objectsCalendarios.addObject(result.valueForKey("lista")!)
//                }
//            }
//        } catch {
//            print("error to show - lista")
//        }
//        if (objectsCalendarios.count == 0){
//            self.atualizandoC.text = "Nenhum calendário disponível"
//        }
//        self.tableView.reloadData()
//        self.actInd.stopAnimating()
//        
//    }
//    
//    // Table View
//    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return objectsCalendarios.count
//    }
//    
//    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
//        let cell = self.tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) as! TableViewCell2
//        cell.titleLabel.text = objectsCalendarios.objectAtIndex(indexPath.row) as? String
//        //        masterCalendario = objectsCalendarios.objectAtIndex(indexPath.row) as! String // variavel que guarda o calendario que está sendo usado
//        
//        return cell
//    }
//    
//    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//        self.performSegueWithIdentifier("openCalendar", sender: self)
//    }
//    
//    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
//        
//        if (segue.identifier == "openCalendar"){
//            var upcoming: UIViewController = segue.destinationViewController as! UIViewController
//            
//            let indexPath = self.tableView.indexPathForSelectedRow!
//            
//            let titleString = objectsCalendarios.objectAtIndex(indexPath.row) as? String
//            
//            masterCalendario = titleString!
//            
//            //            self.tableView.deselectRowAtIndexPath(indexPath, animated: true)
//        }
//    }
//    
//    // md5
//    
//    func md5(string string: String) -> String {
//        var digest = [UInt8](count: Int(CC_MD5_DIGEST_LENGTH), repeatedValue: 0)
//        if let data = string.dataUsingEncoding(NSUTF8StringEncoding) {
//            CC_MD5(data.bytes, CC_LONG(data.length), &digest)
//        }
//        
//        var digestHex = ""
//        for index in 0..<Int(CC_MD5_DIGEST_LENGTH) {
//            digestHex += String(format: "%02x", digest[index])
//        }
//        
//        return digestHex
//    }
//    
//    
//    // verificar se está conectado a internet
//    
//    struct Functions {
//        
//        static func isConnectedToNetwork() -> Bool {
//            var zeroAddress = sockaddr_in()
//            zeroAddress.sin_len = UInt8(sizeofValue(zeroAddress))
//            zeroAddress.sin_family = sa_family_t(AF_INET)
//            let defaultRouteReachability = withUnsafePointer(&zeroAddress) {
//                SCNetworkReachabilityCreateWithAddress(nil, UnsafePointer($0))
//            }
//            var flags = SCNetworkReachabilityFlags()
//            if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
//                return false
//            }
//            let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
//            let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
//            return (isReachable && !needsConnection)
//        }
//        
//    }
//    
//}