//
//  Lista.swift
//  SwiftExample
//
//  Created by Paulo Atavila on 20/06/16.
//  Copyright © 2016 wenchao. All rights reserved.
//

import UIKit
import CoreData

class Lista: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var objectsTipo: NSMutableArray! = NSMutableArray()
    
    @IBOutlet weak var tableView: UITableView!
    
    struct Objects {
        var sectionObjects: [String]!
        var sectionName: String!
    }
    
    var objectsArray = [Objects]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Cadê???")
        
        
        
        
        
        
        // Por tipo
        var i=0
        
        let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let context : NSManagedObjectContext = appDel.managedObjectContext
        let request = NSFetchRequest(entityName: "Eventos")
        request.returnsObjectsAsFaults = false
        
        objectsTipo.removeAllObjects()
        request.predicate = NSPredicate(format: "calendario = %@", masterCalendario)
        do {
            let results = try context.executeFetchRequest(request)
            
            if results.count > 0 {
                for result in results {
                    
                    
                    let tipo = result.valueForKey("tipo") as! String
                    print("olha o tipo: \(tipo)")
                    
                    
                    var tttt = 0
                    for (i=0; i < objectsTipo.count; i+=1){
                        if (objectsTipo[i] as! String == tipo){
                            tttt = 1
                        }
                    }
                    if (tttt != 1){
                        
                        print("vez de salvar: \(tipo)")
                        objectsTipo.addObject(tipo)
                        
                        var objetos = [""]
                        objetos.removeAll()
                        request.predicate = NSPredicate(format: "calendario = %@", masterCalendario)
                        do {
                            let results = try context.executeFetchRequest(request)
                            
                            if results.count > 0 {
                                for result in results {
                                    let tipo2 = result.valueForKey("tipo")
                                    if ((tipo2 as! String) == tipo){
                                        let nome = result.valueForKey("nome")
                                        objetos.append(nome as! String)
                                        
                                    }
                                    
                                }
                                
                            }
                            
                            
                        } catch {
                            print("Error to ShowDentro")
                        }
                        objectsArray.append(Objects(sectionObjects: objetos, sectionName: tipo))
                    }
                    
                }
            }
            
            
        } catch {
            print("Error to ShowFora")
        }

        self.tableView.reloadData()
        
        
    }
    
    
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) as! TableViewCell3
        cell.titleLabel.text = objectsArray[indexPath.section].sectionObjects[indexPath.row]
        
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return objectsArray[section].sectionObjects.count
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return objectsArray.count
    }
    
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return objectsArray[section].sectionName
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.performSegueWithIdentifier("details2", sender: self)
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "details2"){
            var upcoming: NewViewController = segue.destinationViewController as! NewViewController
            let indexPath = self.tableView.indexPathForSelectedRow!
            let titleString = objectsArray[indexPath.section].sectionObjects[indexPath.row]
            upcoming.titleString = titleString
            self.tableView.deselectRowAtIndexPath(indexPath, animated: true)
        }
    }
    
}
