//
//  FSTableViewController.h
//  FSCalendar
//
//  Created by DingWenchao on 6/25/15.
//  Copyright (c) 2015 =. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSTableViewController : UITableViewController

@property (strong, nonatomic) NSArray *viewControllers;

@end
